#pragma once
#include "lvgl.h"
#include "esp_err.h"
#include "esp_lcd_touch.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int i2c_port;          // I2C_NUM_0 or I2C_NUM_1
    int sda_io;            // your SDA GPIO
    int scl_io;            // your SCL GPIO
    int int_io;            // set -1 if not wired
    int rst_io;            // set -1 if not wired
    uint32_t i2c_hz;       // e.g. 100000 with internal pull-ups
    uint8_t i2c_addr_7bit; // 0x38 for FT6336/FT5x06
    uint16_t x_max;        // must match LVGL width after rotation
    uint16_t y_max;        // must match LVGL height after rotation
    bool swap_xy;          // match your panel orientation
    bool mirror_x;
    bool mirror_y;
} touch_ft_cfg_t;

esp_err_t touch_ft6336_init(const touch_ft_cfg_t *cfg, esp_lcd_touch_handle_t *out_tp);
lv_indev_t *touch_lvgl_register(esp_lcd_touch_handle_t tp);
void touch_dbg_start(lv_indev_t *indev);  // optional: periodic log of coords

#ifdef __cplusplus
}
#endif
