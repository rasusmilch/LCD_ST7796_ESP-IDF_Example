#include "touch_ft6336.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/i2c_master.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_touch.h"
#include "esp_lcd_touch_ft5x06.h"

static const char *TAG = "touch_ft6336";

static esp_lcd_touch_handle_t s_tp = NULL;
static lv_indev_t *s_indev = NULL;

esp_err_t touch_ft6336_init(const touch_ft_cfg_t *cfg, esp_lcd_touch_handle_t *out_tp)
{
    if (!cfg || !out_tp) return ESP_ERR_INVALID_ARG;

    // 1) I2C master bus (use internal pull-ups if that’s all you have)
    i2c_master_bus_config_t bus_cfg = {
        .i2c_port = cfg->i2c_port,
        .sda_io_num = cfg->sda_io,
        .scl_io_num = cfg->scl_io,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags = { .enable_internal_pullup = 1 },
    };
    i2c_master_bus_handle_t i2c_bus = NULL;
    ESP_RETURN_ON_ERROR(i2c_new_master_bus(&bus_cfg, &i2c_bus), TAG, "i2c bus create failed");

    // 2) Panel-IO over I2C (required by esp_lcd_touch_* drivers)
    esp_lcd_panel_io_i2c_config_t io_cfg = {
        .dev_addr = cfg->i2c_addr_7bit,    // 0x38
        .scl_speed_hz = cfg->i2c_hz,       // start at 100k if only internal pull-ups
        .control_phase_bytes = 1,
        .dc_bit_offset = 0,
        .lcd_cmd_bits = 8,
        .lcd_param_bits = 8,
    };
    esp_lcd_panel_io_handle_t io = NULL;
    ESP_RETURN_ON_ERROR(esp_lcd_new_panel_io_i2c(i2c_bus, &io_cfg, &io), TAG, "panel_io_i2c failed");

    // 3) Touch device
    esp_lcd_touch_config_t tp_cfg = {
        .x_max = cfg->x_max,
        .y_max = cfg->y_max,
        .rst_gpio_num = cfg->rst_io,
        .int_gpio_num = cfg->int_io,   // if not wired, set -1
        .flags = {
            .swap_xy  = cfg->swap_xy,
            .mirror_x = cfg->mirror_x,
            .mirror_y = cfg->mirror_y,
        },
    };

    esp_lcd_touch_handle_t tp = NULL;
    ESP_RETURN_ON_ERROR(esp_lcd_touch_new_i2c_ft5x06(io, &tp_cfg, &tp), TAG, "touch new failed");

    s_tp = tp;
    *out_tp = tp;

    ESP_LOGI(TAG, "FT5x06/FT6336 ready @0x%02X (%ux%u) swap_xy=%d mx=%d my=%d",
             cfg->i2c_addr_7bit, cfg->x_max, cfg->y_max,
             (int)cfg->swap_xy, (int)cfg->mirror_x, (int)cfg->mirror_y);

    return ESP_OK;
}

static void touch_lvgl_read_cb(lv_indev_t *indev, lv_indev_data_t *data)
{
    (void)indev;
    if (!s_tp) { data->state = LV_INDEV_STATE_RELEASED; return; }

    // MUST read each poll so the driver refreshes its internal buffer
    esp_lcd_touch_read_data(s_tp);

    uint16_t x[1], y[1];
    uint8_t points = 0;
    bool pressed = esp_lcd_touch_get_coordinates(s_tp, x, y, NULL, &points, 1);

    if (pressed && points) {
        data->state   = LV_INDEV_STATE_PRESSED;
        data->point.x = x[0];
        data->point.y = y[0];
    } else {
        data->state   = LV_INDEV_STATE_RELEASED;
    }
}

lv_indev_t *touch_lvgl_register(esp_lcd_touch_handle_t tp)
{
    s_tp = tp;
    s_indev = lv_indev_create();
    lv_indev_set_type(s_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(s_indev, touch_lvgl_read_cb);
    return s_indev;
}

// --- optional tiny logger to prove LVGL gets points ---
static void tmr_cb(lv_timer_t *t)
{
    (void)t;
    if (!s_indev) return;

    lv_point_t p;
    lv_indev_get_point(s_indev, &p);              // v9 returns void
    lv_indev_state_t st = lv_indev_get_state(s_indev);

    if (st == LV_INDEV_STATE_PRESSED)
        ESP_LOGI("touch_dbg", "touch: %d,%d", (int)p.x, (int)p.y);
}
void touch_dbg_start(lv_indev_t *indev)
{
    (void)indev; // s_indev already set
    lv_timer_create(tmr_cb, 100, NULL); // 10Hz logging while pressed
}
